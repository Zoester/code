//app.js
App({
  onLaunch: function () {
    console.log('App loaded.');
  },
  globalData: {
    stories: [
      { content: "OMG!!", name: "Yinghui" },
      { content: "Are you sure?", name: "Sophia" }
    ]
  }
})